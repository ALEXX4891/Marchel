<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style1.css">
  <link rel="stylesheet" href="/reset.css">
    <title>Document</title>
</head>
<body>
    

<div class="css-modal-target" id="css-modal-target">
          <div class="cmt">
            <div class="rigth_card-contacts22">
              <button class="css-modal-details1b close_krest1"><a href="/index.php"><img src="/img-icons/kresst.svg" alt=""></a></button>
              <p class="text_modal-thx">ЗАЯВКА ОТПРАВЛЕНА</p>
              <p class="text_modal-v-blij">Спасибо за доверие, мы скоро свяжемся с вами</p>
              <div class="btn2_Horosho">
                <a href="/index.php" class="btn_Horosho">
                  <img src="/img-icons/like.svg" class = "img2" alt="">
                </a>
              </div>
            </div>
          </div>
          <a href="#close" class="css-modal-close"></a>
        </div>


        </body>
</html>